#include <stdio.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <stdlib.h>     /* General Utilities */
#include <pthread.h>    /* POSIX Threads */
#include <string.h>     /* String handling */
#include <semaphore.h> 
#include <unistd.h>     /* Symbolic Constants */
#include <sys/types.h>  /* Primitive System Data Types */ 
#include <errno.h>      /* Semaphore */


sem_t mutex;
int counter;
void *handler ( void *ptr) ;


int main ()
{
  key_t shm_key = 6166529;
  const int shm_size = 1024;

  int shm_id;
  char* shmaddr, *ptr;
  char* shared_memory[3];
  int *p;

  /* Allocate a shared memory segment. */
  shm_id = shmget (shm_key, shm_size, IPC_CREAT | S_IRUSR | S_IWUSR);

  /* Attach the shared memory segment. */
  shmaddr = (char*) shmat (shm_id, 0, 0);

  printf ("shared memory attached at address %p\n", shmaddr);

  /* Start to read data. */
  p = (int *)shmaddr;
  ptr = shmaddr + sizeof (int) * 2;
  shared_memory[0] = ptr;
  ptr += *p++;
  shared_memory[1] = ptr;
  ptr += *p;
  shared_memory[2] = ptr;


counter = 0 ;

 int i[2];
    pthread_t thread_a;
    pthread_t thread_b;
    
    i[0] = 0; /* argument to threads */
    i[1] = 1;
    
    sem_init(&mutex, 0, 1);      /* initialize mutex to 1 - binary semaphore */
      
    int n ;                           /* second param = 0 - semaphore is local */
                                 
    /* Note: you can check if thread has been successfully created by checking return value of

     pthread_create */ 
  int j = 25 ;
  
   while(j != 0)
  {

  j-- ;

  n = rand()%(2+1-0) +0  ; 
                      
    pthread_create (&thread_a, NULL, (void *) &handler,shared_memory[n]);

    n = rand()%(2+0-0) + 0 ;

    pthread_create (&thread_b, NULL, (void *) &handler,shared_memory[n]);
    
    pthread_join(thread_a, NULL);
    pthread_join(thread_b, NULL);

    
   }
    sem_destroy(&mutex); /* destroy semaphore */
                   
    /* exit */   
    exit(0);
 

  /* Detach the shared memory segment. */
  shmdt (shmaddr);

}


void *handler (void *ptr)
{
    int m ;
    

    char *x = (char *) ptr  ;     


    sem_wait(&mutex);       /* down semaphore */
    
  printf("\ncustomer arrived at COUNTER-1 waited for 5 seconds\n");
   printf("COUNTER-1: Now in critical region...\n");
   printf("%s flavour required by the customer\n",x) ;
   printf("ice-cream is filling wait please\n") ;
   sleep(5) ;
   printf("\n WOW!!! your %s flavour icecream is ready Sir\n\n",x) ;
     
 /* END CRITICAL REGION */
    sem_post(&mutex);       /* up semaphore */
    
    pthread_exit(0); /* exit thread */
}








